package com.example.pertemuan5;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Menu4 extends AppCompatActivity {
    TextView Hasil_Angka;
    EditText Text_Angka;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu4);

        Text_Angka = findViewById(R.id.Txt_Angka);
        Hasil_Angka = findViewById(R.id.Lbl_Angka);
    }
    public void Tampil_Angka(View v){
        int x=1;
        int y = x *x ;
        int angka =Integer.parseInt(Text_Angka.getText().toString()) ;
        while (y!=angka){
            x = x + 1;
            y = x * x;
        }
        Hasil_Angka.setText("Akar dari : "+x);
    }
}
