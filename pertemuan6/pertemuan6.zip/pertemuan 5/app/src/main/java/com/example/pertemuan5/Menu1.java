package com.example.pertemuan5;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Menu1 extends AppCompatActivity {
    //deklarasi object java
    Button BtnMerah, BtnHijau;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu1);

        //Hubungan object java dengan ID XML
        BtnMerah = (Button)findViewById(R.id.Btn1);
        BtnHijau = (Button)findViewById(R.id.Btn2);
    }

    //code merubah warna
    public void Rubah_Warna(View v){
        BtnMerah.setBackgroundColor(Color.RED);
    }

    public void Rubah_Warna1(View v){
        BtnHijau.setBackgroundColor(Color.GREEN);
    }
}
